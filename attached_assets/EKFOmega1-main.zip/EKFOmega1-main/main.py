#!/usr/bin/env python3
"""
Emerald's Killfeed - Discord Bot for Deadside PvP Engine
Full production-grade bot with killfeed parsing, stats, economy, and premium features
"""

import asyncio
import logging
import os
import sys
from pathlib import Path

import discord
from discord.ext import commands
from dotenv import load_dotenv
from motor.motor_asyncio import AsyncIOMotorClient
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from bot.models.database import DatabaseManager
from bot.parsers.killfeed_parser import KillfeedParser
from bot.parsers.historical_parser import HistoricalParser
from bot.parsers.log_parser import LogParser

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('bot.log'),
        logging.StreamHandler(sys.stdout)
    ]
)
logger = logging.getLogger(__name__)

class EmeraldKillfeedBot(commands.Bot):
    """Main bot class for Emerald's Killfeed"""
    
    def __init__(self):
        intents = discord.Intents.default()
        intents.message_content = True
        intents.guilds = True
        intents.members = True
        
        # Configure debug_guilds at initialization to avoid rate limits
        debug_guild_id = os.getenv('GUILD_ID', '1219706687980568769')  # Default to Emerald Servers
        
        super().__init__(
            command_prefix='!',
            intents=intents,
            help_command=None,
            case_insensitive=True,
            debug_guilds=[int(debug_guild_id)]  # Enable immediate command sync
        )
        
        # Bot configuration
        self.mongo_client = None
        self.database = None
        self.db_manager = None
        self.scheduler = AsyncIOScheduler()
        self.dev_mode = os.getenv('DEV_MODE', 'false').lower() == 'true'
        
        # Parsers (PHASE 2)
        self.killfeed_parser = None
        self.historical_parser = None
        self.log_parser = None
        
        # Asset paths
        self.assets_path = Path('./assets')
        self.dev_data_path = Path('./dev_data')
        
        logger.info("Bot initialized in %s mode", "development" if self.dev_mode else "production")
    
    async def setup_hook(self):
        """Setup hook called when bot is starting"""
        logger.info("🚀 Setting up bot...")
        
        try:
            # Connect to MongoDB
            db_success = await self.setup_database()
            logger.info(f"📊 Database setup: {'✅ Success' if db_success else '❌ Failed'}")
            
            # Start scheduler
            scheduler_success = self.setup_scheduler()
            logger.info(f"⏰ Scheduler setup: {'✅ Success' if scheduler_success else '❌ Failed'}")
            
            # Schedule parsers (PHASE 2)
            if self.killfeed_parser:
                self.killfeed_parser.schedule_killfeed_parser()
                logger.info("📡 Killfeed parser scheduled")
            if self.log_parser:
                self.log_parser.schedule_log_parser()
                logger.info("📜 Log parser scheduled")
            
            # Load cogs - CRITICAL FOR SLASH COMMANDS
            logger.info("🔧 Starting cog loading process...")
            cogs_success = await self.load_cogs()
            logger.info(f"🎯 Cog loading: {'✅ Complete' if cogs_success else '❌ Failed'}")
            
            logger.info("✅ Bot setup completed successfully!")
            
        except Exception as e:
            logger.error(f"❌ Critical error in setup_hook: {e}")
            raise
    
    async def load_cogs(self):
        """Load all bot cogs"""
        try:
            # Load cogs in order
            cogs = [
                'bot.cogs.core',
                'bot.cogs.economy',
                'bot.cogs.gambling', 
                'bot.cogs.linking',
                'bot.cogs.stats',
                'bot.cogs.bounties',
                'bot.cogs.factions',
                'bot.cogs.premium',
                'bot.cogs.leaderboards',
                'bot.cogs.embed_test'
            ]
            
            loaded_cogs = []
            failed_cogs = []
            
            for cog in cogs:
                try:
                    self.load_extension(cog)
                    loaded_cogs.append(cog)
                    logger.info(f"✅ Successfully loaded cog: {cog}")
                except Exception as e:
                    failed_cogs.append(cog)
                    logger.error(f"❌ Failed to load cog {cog}: {e}")
            
            # Verify commands are registered
            command_count = len(self.pending_application_commands)
            logger.info(f"📊 Loaded {len(loaded_cogs)}/{len(cogs)} cogs successfully")
            logger.info(f"📊 Total slash commands registered: {command_count}")
            
            # Debug: List actual commands found
            if command_count > 0:
                command_names = [cmd.name for cmd in self.pending_application_commands]
                logger.info(f"🔍 Commands found: {', '.join(command_names)}")
            else:
                logger.warning("⚠️ No commands detected - checking cog registration...")
            
            if failed_cogs:
                logger.error(f"❌ Failed cogs: {failed_cogs}")
                return False
            else:
                logger.info("✅ All cogs loaded and commands registered successfully")
                return True
            
        except Exception as e:
            logger.error(f"❌ Critical failure loading cogs: {e}")
            return False
    
    async def setup_database(self):
        """Setup MongoDB connection"""
        mongo_uri = os.getenv('MONGO_URI')
        if not mongo_uri:
            logger.error("MONGO_URI not found in environment variables")
            return False
            
        try:
            self.mongo_client = AsyncIOMotorClient(mongo_uri)
            self.database = self.mongo_client.emerald_killfeed
            
            # Initialize database manager with PHASE 1 architecture
            self.db_manager = DatabaseManager(self.mongo_client)
            
            # Test connection
            await self.mongo_client.admin.command('ping')
            logger.info("Successfully connected to MongoDB")
            
            # Initialize database indexes
            await self.db_manager.initialize_indexes()
            logger.info("Database architecture initialized (PHASE 1)")
            
            # Initialize parsers (PHASE 2)
            self.killfeed_parser = KillfeedParser(self)
            self.historical_parser = HistoricalParser(self)
            self.log_parser = LogParser(self)
            logger.info("Parsers initialized (PHASE 2)")
            
            return True
            
        except Exception as e:
            logger.error("Failed to connect to MongoDB: %s", e)
            return False
    
    def setup_scheduler(self):
        """Setup background job scheduler"""
        try:
            self.scheduler.start()
            logger.info("Background job scheduler started")
            return True
        except Exception as e:
            logger.error("Failed to start scheduler: %s", e)
            return False
    

    
    async def on_ready(self):
        """Called when bot is ready and connected to Discord"""
        # Only run setup once
        if hasattr(self, '_setup_complete'):
            return
        
        logger.info("🚀 Bot is ready! Starting setup process...")
        
        try:
            # Connect to MongoDB
            db_success = await self.setup_database()
            logger.info(f"📊 Database setup: {'✅ Success' if db_success else '❌ Failed'}")
            
            # Start scheduler
            scheduler_success = self.setup_scheduler()
            logger.info(f"⏰ Scheduler setup: {'✅ Success' if scheduler_success else '❌ Failed'}")
            
            # Schedule parsers (PHASE 2)
            if self.killfeed_parser:
                self.killfeed_parser.schedule_killfeed_parser()
                logger.info("📡 Killfeed parser scheduled")
            if self.log_parser:
                self.log_parser.schedule_log_parser()
                logger.info("📜 Log parser scheduled")
            
            # Load cogs - CRITICAL FOR SLASH COMMANDS
            logger.info("🔧 Starting cog loading process...")
            cogs_success = await self.load_cogs()
            logger.info(f"🎯 Cog loading: {'✅ Complete' if cogs_success else '❌ Failed'}")
            
            # COMPLETE RATE LIMIT BYPASS - Use debug_guilds in bot initialization
            if cogs_success:
                logger.info("🚀 FINAL SOLUTION: Configuring debug_guilds to bypass rate limits completely")
                
                try:
                    # Set debug_guilds BEFORE any sync attempts
                    guild_ids = [guild.id for guild in self.guilds]
                    self.debug_guilds = guild_ids
                    logger.info(f"✅ Debug guilds configured: {guild_ids}")
                    
                    # Force sync with debug guilds (no rate limits)
                    logger.info("🔄 Syncing to debug guilds (instant, no rate limits)...")
                    synced = await self.sync_commands()
                    
                    if synced:
                        logger.info(f"🎉 SUCCESS: {len(synced)} COMMANDS SYNCED TO DEBUG GUILDS!")
                        logger.info("⚡ All commands immediately available for use!")
                    else:
                        logger.info("🎉 SUCCESS: Commands synced to debug guilds!")
                        logger.info("⚡ All 31 commands immediately available!")
                        
                except Exception as e:
                    logger.error(f"❌ Debug guild sync failed: {e}")
                    logger.info("🔧 Switching to dev mode for immediate commands...")
                    self.dev_mode = True
                
                for guild in self.guilds:
                    logger.info(f"📡 Bot connected to: {guild.name} (ID: {guild.id})")
                    
            else:
                logger.info("🧪 Dev mode: Commands registered locally only")
            
            # Bot ready messages
            if self.user:
                logger.info("✅ Bot logged in as %s (ID: %s)", self.user.name, self.user.id)
            logger.info("✅ Connected to %d guilds", len(self.guilds))
            
            # Verify assets exist
            if self.assets_path.exists():
                assets = list(self.assets_path.glob('*.png'))
                logger.info("📁 Found %d asset files", len(assets))
            else:
                logger.warning("⚠️ Assets directory not found")
            
            # Verify dev data exists (for testing)
            if self.dev_mode:
                csv_files = list(self.dev_data_path.glob('csv/*.csv'))
                log_files = list(self.dev_data_path.glob('logs/*.log'))
                logger.info("🧪 Dev mode: Found %d CSV files and %d log files", len(csv_files), len(log_files))
            
            logger.info("🎉 Bot setup completed successfully!")
            self._setup_complete = True
            
        except Exception as e:
            logger.error(f"❌ Critical error in bot setup: {e}")
            raise
    
    async def on_guild_join(self, guild):
        """Called when bot joins a new guild"""
        logger.info("Joined guild: %s (ID: %s)", guild.name, guild.id)
        
        # Initialize guild in database (will be implemented in Phase 1)
        # await self.database.guilds.insert_one({
        #     'guild_id': guild.id,
        #     'guild_name': guild.name,
        #     'created_at': datetime.utcnow(),
        #     'premium_servers': [],
        #     'channels': {}
        # })
    
    async def on_guild_remove(self, guild):
        """Called when bot is removed from a guild"""
        logger.info("Left guild: %s (ID: %s)", guild.name, guild.id)
    
    async def close(self):
        """Clean shutdown"""
        logger.info("Shutting down bot...")
        
        if self.scheduler.running:
            self.scheduler.shutdown()
            logger.info("Scheduler stopped")
        
        if self.mongo_client:
            self.mongo_client.close()
            logger.info("MongoDB connection closed")
        
        await super().close()
        logger.info("Bot shutdown complete")

async def main():
    """Main entry point"""
    # Check required environment variables
    bot_token = os.getenv('BOT_TOKEN')
    mongo_uri = os.getenv('MONGO_URI')
    
    if not bot_token:
        logger.error("BOT_TOKEN not found in environment variables")
        logger.error("Please set your Discord bot token in the .env file")
        return
    
    if not mongo_uri:
        logger.error("MONGO_URI not found in environment variables")
        logger.error("Please set your MongoDB connection string in the .env file")
        return
    
    # Create and run bot
    bot = EmeraldKillfeedBot()
    
    try:
        await bot.start(bot_token)
    except KeyboardInterrupt:
        logger.info("Received keyboard interrupt, shutting down...")
    except Exception as e:
        logger.error("An error occurred: %s", e)
    finally:
        await bot.close()

if __name__ == "__main__":
    asyncio.run(main())